<?php
require_once 'config.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'add':
        $data = json_decode(file_get_contents('php://input'), true);
        $stmt = $pdo->prepare("INSERT INTO items (name, quantity, price) VALUES (?, ?, ?)");
        $stmt->execute([$data['name'], $data['quantity'], $data['price']]);
        echo json_encode(['status' => 'success']);
        break;

    case 'update':
        $data = json_decode(file_get_contents('php://input'), true);
        $stmt = $pdo->prepare("UPDATE items SET name = ?, quantity = ?, price = ? WHERE id = ?");
        $stmt->execute([$data['name'], $data['quantity'], $data['price'], $data['id']]);
        echo json_encode(['status' => 'success']);
        break;

    case 'get':
        $search = $_GET['search'] ?? '';
        $sort = $_GET['sort'] ?? 'id';
        $validSort = in_array($sort, ['id', 'name', 'quantity', 'price']) ? $sort : 'id';
        
        $query = "SELECT * FROM items";
        $params = [];
        if ($search) {
            $query .= " WHERE LOWER(name) LIKE LOWER(?)";
            $params[] = "%$search%";
        }
        $query .= " ORDER BY $validSort";
        
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($items);
        break;

    case 'delete':
        $id = $_GET['id'] ?? 0;
        $stmt = $pdo->prepare("DELETE FROM items WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(['status' => 'success']);
        break;

    default:
        echo json_encode(['error' => 'Invalid action']);
}
?>