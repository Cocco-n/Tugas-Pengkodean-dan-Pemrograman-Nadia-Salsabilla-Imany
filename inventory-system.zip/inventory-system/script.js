document.addEventListener('DOMContentLoaded', () => {
    loadInventory();
    
    const itemForm = document.getElementById('itemForm');
    const searchInput = document.getElementById('searchInput');
    const sortBy = document.getElementById('sortBy');
    
    // Handle form submission
    itemForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const item = {
            id: document.getElementById('itemId').value,
            name: document.getElementById('name').value,
            quantity: document.getElementById('quantity').value,
            price: document.getElementById('price').value
        };

        const action = item.id ? 'update' : 'add';
        await fetch(`process.php?action=${action}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(item)
        });
        
        loadInventory();
        resetForm();
    });

    // Debounce untuk pencarian
    let debounceTimeout;
    searchInput.addEventListener('input', () => {
        clearTimeout(debounceTimeout);
        debounceTimeout = setTimeout(() => {
            loadInventory();
        }, 300); // Delay 300ms
    });

    // Sort functionality
    sortBy.addEventListener('change', () => {
        loadInventory();
    });

    // Cancel edit
    document.getElementById('cancelBtn').addEventListener('click', resetForm);
});

// Load inventory data
async function loadInventory() {
    const search = document.getElementById('searchInput').value.toLowerCase();
    const sortBy = document.getElementById('sortBy').value;
    
    const response = await fetch(`process.php?action=get&search=${encodeURIComponent(search)}&sort=${sortBy}`);
    const items = await response.json();
    const inventoryList = document.getElementById('inventoryList');
    inventoryList.innerHTML = '';

    items.forEach(item => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${item.id}</td>
            <td>${item.name}</td>
            <td>${item.quantity}</td>
            <td>Rp ${parseFloat(item.price).toLocaleString('id-ID')}</td>
            <td>
                <button class="action-btn edit-btn" onclick="editItem(${item.id}, '${item.name}', ${item.quantity}, ${item.price})">Edit</button>
                <button class="action-btn delete-btn" onclick="showDeleteModal(${item.id})">Hapus</button>
            </td>
        `;
        inventoryList.appendChild(tr);
    });
}

// Edit item
function editItem(id, name, quantity, price) {
    document.getElementById('formTitle').textContent = 'Edit Item';
    document.getElementById('itemId').value = id;
    document.getElementById('name').value = name;
    document.getElementById('quantity').value = quantity;
    document.getElementById('price').value = price;
    document.getElementById('submitBtn').textContent = 'Update';
    document.getElementById('cancelBtn').style.display = 'inline-block';
}

// Reset form
function resetForm() {
    document.getElementById('itemForm').reset();
    document.getElementById('itemId').value = '';
    document.getElementById('formTitle').textContent = 'Tambah Item Baru';
    document.getElementById('submitBtn').textContent = 'Tambah';
    document.getElementById('cancelBtn').style.display = 'none';
}

// Delete modal
function showDeleteModal(id) {
    const modal = document.getElementById('deleteModal');
    modal.style.display = 'flex';
    
    document.getElementById('confirmDelete').onclick = async () => {
        await fetch(`process.php?action=delete&id=${id}`, {
            method: 'POST'
        });
        loadInventory();
        modal.style.display = 'none';
    };
    
    document.getElementById('cancelDelete').onclick = () => {
        modal.style.display = 'none';
    };
}